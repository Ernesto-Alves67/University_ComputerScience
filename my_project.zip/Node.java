

public class Node {
    
    private String element;
    private Node next;
    public Node(){}
    
}