
public class SimpleLinkedList{
    
    protected Node head;
    protected Node tail;
    protected long size;
    
    public SimpleLinkedList(){
        head.element = "";
        head.next = null;
        size = 0;
        tail.element ="";
        tail.next = null;
    }
    
    public void addFirst(String v){
        
    }
    
    public String getHead(){
        return head.element; 
    }
    
}